
 
public class UpperCaseException extends Exception{
	 public UpperCaseException() {
	     super("Password needs to contain at least 1 uppercase"
			 		+ " character"););
	}

}


public class LengthException extends Exception{

	public LengthException() {
	     super("Password needs to be at least 6 characters long");
	}

}

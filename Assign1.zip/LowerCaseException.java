 
public class LowerCaseException extends Exception{
 
	public LowerCaseException() {
	     super("Password needs to contain at least 1 lowercase"
			 		+ " character");
	}

}

 
public class ValidSequenceException extends Exception{
	 
	public ValidSequenceException() {
	     super("Password cannot have 2 of the same characters");
	}

}

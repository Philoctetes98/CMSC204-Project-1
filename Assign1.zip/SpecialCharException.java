 
public class SpecialCharException extends Exception{
 
	public SpecialCharException() {
	     super("Password needs to contain at least 1 special"
			 		+ " character");
	}

}

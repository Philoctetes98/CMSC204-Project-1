
public class DigitException extends Exception{
 
	public DigitException() {
	     super("Password needs to contain at least 1 digit");
	}

}


import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordCheckerUtility {
	private String password;
	private ArrayList<String> invalidPasswords;
	
	//Checks if the password is at least 6 characters long
	private static boolean lengthCheck(String password) throws LengthException{
		if(password.length() < 6)
			throw new LengthException();
		else
			return true;
	}
	
	//Checks if the password has any uppercase characters
	private static boolean upperCaseCheck(String password) throws UpperCaseException{
		if (password.equals(password.toLowerCase())) {
			throw new UpperCaseException();
		}
		else
			return true;
	}
	
	//Checks if the password has any lowercase characters
	private static boolean lowerCaseCheck(String password) throws LowerCaseException{
		if (password.equals(password.toUpperCase())) {
			throw new LowerCaseException();
		}
		else
			return true;
	}
	
	//Checks if the password has any special characters
	private static boolean isSpecialCharCheck(String password) throws SpecialCharException{
		String special = "[^A-Za-z0-9]+";
		 Pattern pt = Pattern.compile(special);
		 Matcher mt = pt.matcher(password);
		 
		 if (mt.matches()) {
			 throw new SpecialCharException();
		 }
		 else
				return true;
	}
	
	//Checks if the password has any numeric characters
	private static boolean isDigitCheck(String password) throws DigitException {
		 
		 char [] passwordCh = password.toCharArray();
		 int count = 0;
		 
		 for(int index = 0; index < passwordCh.length; index++) {
			 if(Character.isDigit(passwordCh[index]));
			      count++;
		 }
		 
		 if(count == 0) {
			 throw new DigitException();
		 }
		 else
			 return true;
	}
 
	
	//Checks to see if the password has 2 of the same characters in it
	private static boolean isValidSeqCheck(String password) throws ValidSequenceException {
		 
		boolean flag = true;
		 
		for (int index = 0; index < password.length() - 2; index++) {
			if (password.charAt(index) == password.charAt(index+1)) {
				if(password.charAt(index) == password.charAt(index+2)) {
					flag = false;
					throw new ValidSequenceException();
				}
			}
		}
		return flag;
	}
	
	//Checks if a string fulfills all of the requirements to become a valid
	// password
	public static boolean isValidPassword(String password) throws LengthException,
	DigitException, UpperCaseException, LowerCaseException, SpecialCharException,
	ValidSequenceException {
		boolean length = false, upper = false, lower = false, digit = false,
				special = false, validseq = false, flag = true;
		
		try	{
			length = lengthCheck(password);
			upper = upperCaseCheck(password);
			lower = lowerCaseCheck(password);
			digit = isDigitCheck(password);
			special = isSpecialCharCheck(password);
			validseq = isValidSeqCheck(password);
		} 
		finally {
			if(length == true && upper == true && lower == true && digit == true
					&& special == true && validseq == true) {
				flag = true;
 
			}
			else {
				flag = false;
  
		}
		return flag;    
		}
	}
	
 //Checks if the password is weak or strong
	public static boolean isWeakPassword(String password) {
		boolean flag = true;
		
		if (password.length() < 6 || password.length() > 9) {
			flag = false;
		}
		return flag;
	}
	
	//Checks to find any invalid passwords in the password list
	public static ArrayList<String> validPasswordList(ArrayList<String> passwords){
		ArrayList<String> password = new ArrayList<String>();
		String invalidPassword = null;
		
		for (int index = 0; index < passwords.size(); index++ ) {
			try {
				invalidPassword = passwords.get(index);
				if(!isValidPassword(invalidPassword))
					invalidPassword=invalidPassword+"";
			}
			catch(Exception e) {
				password.add(invalidPassword + e.getMessage());
			}
		}
		
		return passwords;
	}                                                     
}
